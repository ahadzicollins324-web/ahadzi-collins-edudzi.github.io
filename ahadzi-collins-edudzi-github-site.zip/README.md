# Personal GitHub Pages Website

## Quick setup

1. Create a new **public** GitHub repository.
2. Upload `index.html`, `style.css`, `robots.txt`, `sitemap.xml`, and the `assets` folder.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main`, and choose `/ (root)`.
5. Save and wait for GitHub Pages to publish the site.
6. Replace `Ahadzi Collins Edudzi` everywhere with your real name.
7. Replace the `#` social links with your real profile URLs.
8. Replace the placeholder GitHub Pages URL in `robots.txt` and `sitemap.xml` with your actual URL.

## Google visibility

Google may index the page after it is publicly available, but there is no guarantee that it will appear in a particular position or that the image will appear in Google Images. Using your real name consistently in the page title, heading, image alt text, and public profiles can help Google understand the page.

For stronger indexing, you can also add the site to Google Search Console after it is live.
